# coding: utf-8
import os

from .. import app, db, csrf
from ..models.user_models import User
from flask_login import current_user, login_required
from flask import (request, render_template, jsonify, flash, g, redirect, url_for, abort)
from ..forms.pod_forms import (PodCreateForm)
from ..models.pod_models import Pod, PodAppointment, Feedback
from config import media_dir
from datetime import datetime, timedelta
from ..utils.common import save_file, paginate_helper, get_utc_now
from ..mails.email import send_email
import holidays


@app.route('/pod/create', methods=['post', 'get'])
@login_required
def pod_create():
    """

    :return:
    """
    form = PodCreateForm()
    if form.validate_on_submit():
        obj = Pod(name=form.name.data, lat=form.lat.data, lon=form.lon.data)
        db.session.add(obj)
        db.session.commit()
        flash(message='Pod created', category='success')
        return redirect('/pods')

    return render_template('pods/pod_create.html', form=form, title='Pod Create')


@app.route('/pod/update/<int:pod_id>', methods=['post', 'get'])
@login_required
def pod_update(pod_id):
    """

    :return:
    """
    obj = Pod.query.filter(Pod.id == pod_id).first_or_404()
    form = PodCreateForm(name=obj.name, lat=obj.lat, lon=obj.lon)
    if form.validate_on_submit():
        obj.name = form.name.data
        obj.lat = form.lat.data
        obj.lon = form.lon.data

        db.session.add(obj)
        db.session.commit()
        flash(message='Pod Updated', category='success')
        return redirect('/pod/list')

    return render_template('pods/pod_create.html', form=form, title='Pod Update')


@app.route('/pod/delete/<int:pod_id>', methods=['post', 'get'])
@login_required
def pod_delete(pod_id):
    """
    pod delete
    :return:
    """
    obj = Pod.query.filter(Pod.id == pod_id).first()
    if obj:
        db.session.delete(obj)
        db.session.commit()
    return jsonify(success=True)


@app.route('/pod/list/json')
@login_required
def pod_list_json():
    """

    :return:
    """
    ls = []
    for obj in Pod.query.order_by(Pod.created_at.desc()).all():
        ls.append({'id': obj.id, 'name': obj.name, 'lat': obj.lat, 'lon': obj.lon})
    return jsonify(success=True, data=ls)


@app.route('/pod/list')
@login_required
def pod_list_page():
    """

    :return:
    """
    return render_template('pods/pod_list.html', ls=Pod.query.order_by(Pod.created_at.desc()), title='Pod List')


@app.route('/pods')
@login_required
def pods_map():
    return render_template('pods/pods_map.html', title='Pods Map')


@app.route('/pod/calendar/<int:pod_id>')
@login_required
def pod_calendar(pod_id):
    obj = Pod.query.filter(Pod.id == pod_id).first_or_404()
    return render_template('pods/calendar.html', title='Choose the Date', pod_id=pod_id)


@app.route('/pod/calendar/<int:pod_id>/<int:year>-<int:month>-<int:day>')
@login_required
def pod_time_period(pod_id, year, month, day):
    obj = Pod.query.filter(Pod.id == pod_id).first_or_404()
    user = current_user

    now = datetime.now()

    p1 = datetime(year=int(year), month=int(month), day=int(day))
    p2 = p1 + timedelta(days=1) - timedelta(hours=(24-18))
    p1 += timedelta(hours=11)

    ks = []
    t = p1
    while t < p2:
        ks.append(t)
        t += timedelta(minutes=30)

    us = [True if i >= now else False for i in ks]

    ls = [i.strftime('%Y-%m-%d %H:%M - ') + (i + timedelta(minutes=30)).strftime('%H:%M') for i in ks]

    for i in PodAppointment.query.filter(PodAppointment.pod_id == pod_id).filter(PodAppointment.start >= p1).filter(
            PodAppointment.start < p2).all():
        _ = i.start.strftime('%Y-%m-%d %H:%M - ') + i.end.strftime('%H:%M')
        us[ls.index(_)] = False

    # disable weekends
    if p1.weekday() in [5, 6]:
        us = [False for i in us]
    # disable holidays
    us_holidays = holidays.country_holidays('US')
    if us_holidays.get(p1.strftime('%Y-%m-%d')) is not None:
        us = [False for i in us]

    return render_template('pods/time.html', title='Choose the period', ls=zip(ls, us),
                           the_date=p1.strftime('%Y-%m-%d'), pod_id=pod_id)


@app.route('/pod/calendar/apply', methods=['post'])
@csrf.exempt
@login_required
def pod_apply_period():
    # todo user
    user = current_user

    data = request.get_json()

    pod_id = data.get('pod_id')
    pod_obj: Pod = Pod.query.filter(Pod.id == pod_id).first()
    if pod_obj is None:
        return jsonify(success=False, msg='Pod did not exist')

    day = data.get('day')
    p1 = datetime.strptime(day, '%Y-%m-%d')
    p2 = p1 + timedelta(days=1)

    ms = []
    for i in PodAppointment.query.filter(PodAppointment.pod_id == pod_id).filter(PodAppointment.start >= p1).filter(
            PodAppointment.start < p2).all():
        ms.append(i)

    period = data.get('period')
    if period in ms:
        return jsonify(success=False, msg='Period is not available')

    s, t = period.split(' - ')
    s = datetime.strptime(s, '%Y-%m-%d %H:%M')
    t = datetime.strptime(day + ' ' + t, '%Y-%m-%d %H:%M')

    appointment_obj = PodAppointment(user_id=user.id, pod_id=pod_id, start=s, end=t)
    db.session.add(appointment_obj)
    db.session.commit()
    return jsonify(success=True)


@app.route('/pod/appoints/my', methods=['get'])
@login_required
def pod_my_appoints():
    # todo user
    user = current_user

    ls = PodAppointment.query.filter(PodAppointment.user_id == user.id).order_by(PodAppointment.created_at.desc())
    now = datetime.now()
    return render_template('pods/pod_appoints.html', title='My Appointments', ls=ls, now=now)


@app.route('/pod/appoint/feedback', methods=['post'])
@csrf.exempt
@login_required
def pod_appoint_feedback():
    """

    :return:
    """
    print(request.data)
    # todo user
    user = current_user

    data = request.get_json()

    app_id = data.get('app_id')
    content = data.get('content')

    appointment_obj: PodAppointment = PodAppointment.query.filter(PodAppointment.id == app_id).first()

    feedback_obj = Feedback()

    feedback_obj.user_id = user.id
    feedback_obj.pod_id = appointment_obj.pod_id
    feedback_obj.appointment_id = app_id
    feedback_obj.content = content
    db.session.add(feedback_obj)
    db.session.commit()

    send_email(to=app.config.get('MAIL_DEFAULT_SENDER'), subject=f'Received feedback about {appointment_obj.pod.name}',
               html=render_template('email/feedback_template.html', email=user.email, pod_name=appointment_obj.pod.name,
                                    the_date=appointment_obj.start.strftime('%Y-%m-%d'),
                                    time_from=appointment_obj.start.strftime('%H:%M'),
                                    time_to=appointment_obj.end.strftime('%H:%M'),
                                    content=content))

    return jsonify(success=True)


@app.route('/pod/feedbacks', methods=['get'])
@login_required
def pod_feedbacks():
    ls = Feedback.query.order_by(Feedback.created_at.desc())
    return render_template('pods/feedbacks.html', title='Feedbacks', ls=ls)


@app.route('/pod/player')
@app.route('/pod/player/<int:app_id>')
def pod_music_player(app_id=None):
    return render_template('pods/player.html', title='Enjoy Music')


@app.route('/pod/alarm/status', methods=['post'])
@login_required
@csrf.exempt
def pod_appointment_alarm_status_query():
    """
    check alarm status
    :return:
    """
    data = request.get_json()

    user = current_user
    app_id = data.get('app_id')
    app_obj: PodAppointment = PodAppointment.query.filter(PodAppointment.id == app_id).first()
    if app_obj is None:
        return jsonify(success=False, msg='Pod appointment is missing', status=None)
    return jsonify(success=True, msg='Alarm on' if app_obj.is_alarm_on else 'Alarm off', status=app_obj.is_alarm_on)


@app.route('/pod/alarm/batch-status', methods=['post'])
@login_required
@csrf.exempt
def pod_appointment_alarm_batch_query_status():
    """
    check alarm status
    :return:
    """
    data = request.get_json()

    user = current_user
    ls = data.get('ls')
    res = {}
    for obj in PodAppointment.query.filter(PodAppointment.id.in_(ls)).all():
        res[str(obj.id)] = obj.is_alarm_on
    return jsonify(success=True, data=res)


@app.route('/pod/alarm/change', methods=['post'])
@login_required
@csrf.exempt
def pod_appointment_alarm_status_change():
    """
    check alarm status
    :return:
    """
    data = request.get_json()

    user = current_user
    app_id = data.get('app_id')
    app_obj: PodAppointment = PodAppointment.query.filter(PodAppointment.id == app_id).first()
    if app_obj is None:
        return jsonify(success=False, msg='Pod appointment is missing', status=None)
    target_status = data.get('target_status')
    app_obj.is_alarm_on = bool(target_status)
    db.session.add(app_obj)
    db.session.commit()
    return jsonify(success=True, msg='Alarm on' if app_obj.is_alarm_on else 'Alarm off', status=app_obj.is_alarm_on)


