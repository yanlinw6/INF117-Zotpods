# coding: utf-8
from .. import app
from flask import render_template
from flask import flash
from flask import abort, request, url_for
from flask import send_file
from flask_login import login_required, current_user
import os
from config import media_dir, default_upload_dir
from datetime import datetime, timedelta, timezone

from flask_ckeditor import upload_fail, upload_success
from werkzeug.utils import secure_filename
from ..utils.common import save_file


@app.route('/')
def index():
    return render_template('index.html', title='Welcome to ZotPods')


@app.route('/media/<path:file_path>', methods=['GET'])
def media(file_path):
    abs_path = os.path.abspath(os.path.join(media_dir, file_path))
    if not os.path.exists(abs_path):
        abort(404)
    return send_file(abs_path)





