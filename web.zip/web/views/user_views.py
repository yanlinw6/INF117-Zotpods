# coding: utf-8
from .. import app, db, login
from ..models.user_models import User
from flask import flash, render_template
from flask import redirect
from flask import url_for
from flask import request
from flask import abort
from flask_login import current_user, login_user, login_required, logout_user
from werkzeug.urls import url_parse
from werkzeug.utils import secure_filename
from ..forms.user_forms import (RegisterForm, LoginForm, ChangePasswordForm, PasswordResetRequestForm,
                                PasswordResetForm, UpdateAvatarForm, EditProfileForm)
from ..mails.email import send_email
from ..utils.common import save_file
from config import media_dir
from pathlib import Path
from ..utils.common import save_file, paginate_helper, get_utc_now


@app.route('/users')
def users():
    query = User.query.order_by(User.created_at.desc())
    page, per_page = paginate_helper()
    user_ls = query.paginate(page=page, per_page=per_page, error_out=False)
    return render_template('user/user_list.html', title='User List',
                           user_ls=user_ls)


@app.route('/user/register', methods=['get', 'post'])
def user_register():
    """
    user register view
    :return:
    """

    if current_user and current_user.is_authenticated:
        return redirect(url_for('index'))

    form = RegisterForm()
    if form.validate_on_submit():
        user_obj = User()
        user_obj.username = form.username.data
        user_obj.password = form.password.data
        user_obj.email = form.email.data
        user_obj.role = form.role.data
        db.session.add(user_obj)
        db.session.commit()

        token = user_obj.generate_confirmation_token()
        # text = render_template('email/confirm.txt', user=user_obj, token=token)
        html = render_template('email/confirm.html', user=user_obj, token=token)
        print(html)
        try:
            send_email(to=user_obj.email, subject='Confirm Your Account', # text=text,
                html=html, )
        except:
            pass
        flash(message='Your account created. An email with verify-link has been sent to your email address',
              category='info')
        return redirect(url_for('user_login'))
    return render_template('user/user_register.html', title='User Register', form=form)


@app.route('/user/confirm/<token>')
@login_required
def confirm(token):
    '''<CONFIRM> Operation of business logic layer after clicking the link in the email'''
    if current_user.confirmed:
        return redirect(url_for('index'))
    if current_user.confirm(token):
        db.session.commit()
        flash('You have confirmed your account. Thanks!', category="success")
    else:
        flash('The confirmation link is invalid or has expired.', category="danger")
    return redirect(url_for('index'))


@app.route('/user/unconfirmed')
def unconfirmed():
    '''Filter uncomfirmed users to the unconfirmed page'''
    if current_user.is_authenticated and current_user.confirmed:
        return redirect(url_for('index'))
    else:
        return render_template('user/unconfirmed.html', title='Confirm your account')


@app.route('/user/login', methods=['get', 'post'])
def user_login():
    """
    user login view
    :return: 
    """
    next_page = request.args.get('next')
    if not next_page or url_parse(next_page).netloc != '':
        next_page = url_for('index')
    if current_user.is_authenticated:
        return redirect(next_page)

    form = LoginForm()
    if form.validate_on_submit():
        user_obj = User.query.filter((User.username == form.username.data) | (User.email == form.username.data)).first()
        if user_obj is None or not user_obj.check_password(form.password.data):
            flash('Invalid username or password', category='danger')
            return redirect(url_for('user_login'))

        login_user(user_obj, remember=form.remember_me.data)

        user_obj.last_ip = request.remote_addr
        db.session.add(user_obj)
        db.session.commit()
        #
        # if not user_obj.confirmed:
        #     app.logger.warning('%s try to login, but it don\'t confirm the account.' % user_obj.name)
        #     return redirect(url_for('unconfirmed'))
        flash(message='Welcome back', category='success')
        return redirect(next_page)

    return render_template('user/user_login.html', title='User Login', form=form)


@app.route('/user/logout')
@login_required
def user_logout():
    """
    user sign out
    :return:
    """
    logout_user()
    return redirect(url_for('user_login'))


@app.route('/user/update-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """
    update password
    :return: 
    """
    form = ChangePasswordForm()
    if form.validate_on_submit():
        if current_user.verify_password(form.old_password.data):
            current_user.password = form.password.data
            db.session.add(current_user)
            db.session.commit()
            app.logger.info('%s change the password.' % current_user.username)
            flash('Password Updated.', category="success")
        else:
            app.logger.warning('%s tried to change password, but the old password is wrong.' % current_user.username)
            flash('Failed to verify your old password', category="danger")
    return render_template('user/change_password.html', title='Update Password', form=form)


@app.route('/user/reset-password', methods=['GET', 'POST'])
def password_reset_request():
    """
    user request to reset password after forgetting password
    :return: 
    """
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = PasswordResetRequestForm()
    if form.validate_on_submit():
        user_obj = User.query.filter_by(email=form.email.data.lower()).first()
        if user_obj:
            token = user_obj.generate_reset_token()
            text = render_template('email/reset_password.txt', user=user_obj, token=token)
            html = render_template('email/reset_password.html', user=user_obj, token=token)
            print(html)
            try:
                send_email(to=user_obj.email, subject='Reset Password', text=text, html=html)
            except:
                pass
            flash('An email with instructions to reset your password has been sent to you', category="success")
        else:
            flash('No account was connected to your email.', category="warning")

        return redirect(url_for('user_login'))
    return render_template('user/password_reset_request.html', title='Find My Password', form=form)


@app.route('/reset/<token>', methods=['GET', 'POST'])
def password_reset(token):
    """
    user setup a password with a valid token
    :param token:
    :return:
    """
    if current_user.is_authenticated:
        app.logger.error('%s tried to reset password, but it has logged in.' % current_user.username)
        return redirect(url_for('index'))
    form = PasswordResetForm()
    if form.validate_on_submit():
        if User.reset_password(token, form.password.data):
            db.session.commit()
            flash('Password Reset Successfully.', category="success")
            return redirect(url_for('user_login'))
        else:
            return redirect(url_for('index'))
    return render_template('user/reset_password.html', title='Reset Password', form=form)


@app.route('/avatar/upload', methods=['POST'])
@login_required
def avatar_upload():
    form = UpdateAvatarForm()
    if form.validate_on_submit():
        file = request.files.get('avatar')

        abs_dir = Path(media_dir) / 'avatar' / secure_filename(current_user.username)
        abs_fp = save_file(file_obj=file, dir_path=abs_dir)
        current_user.avatar = str(abs_fp.relative_to(media_dir)).replace('\\', '/').replace('//', '/')
        db.session.add(current_user)
        db.session.commit()
        flash(message='Avatar updated', category='success')
    else:
        flash(message='Avatar Update Failed', category='danger')
    return redirect(url_for('edit_profile'))


@app.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if not current_user.confirmed:
        app.logger.warning('%s try to edit profile, but it don\'t confirm the account.' % current_user.username)
        return redirect(url_for('unconfirmed'))
    else:
        avatar_form = UpdateAvatarForm()

        form = EditProfileForm()
        if form.validate_on_submit():
            current_user.fullname = form.fullname.data
            current_user.about_me = form.about_me.data
            db.session.add(current_user)
            db.session.commit()
            app.logger.info('%s update its profile.' % current_user.username)
            flash('Profile Updated.', category="success")
            return redirect(url_for('edit_profile', username=current_user.username))
        else:
            form.fullname.data = current_user.fullname
            form.about_me.data = current_user.about_me
        return render_template('user/edit_profile.html', title='User Profile', form=form, avatar_form=avatar_form)


@app.route('/user/profile/<username>')
@login_required
def user_profile(username):
    user = User.query.filter_by(username=username).first()
    if user is None:
        app.logger.error('%s\' profile can not be found.' % username)
        abort(404)
    if current_user.is_superuser == 3:
        action = request.args.get('action')
        if action == 'disable':
            user.is_active = False
            db.session.add(user)
            db.session.commit()
            flash(message='User Disabled', category='success')
        elif action == 'enable':
            user.is_active = True
            db.session.add(user)
            db.session.commit()
            flash(message='User Restored', category='success')
        elif action == 'delete':
            if current_user.id == user.id:
                flash(message='User can not delete oneself', category='danger')
            else:
                db.session.delete(user)
                db.session.commit()
                flash(message='User Deleted', category='success')
                return redirect(url_for('index'))
        elif action is None:
            pass
        else:
            flash(message='Invalid Operation', category='warning')
    return render_template('user/user_profile.html', title='User Profile', user=user)


@app.route('/user/profile')
@login_required
def user_profile_my():
    return user_profile(username=current_user.username)


@app.route('/confirm')
@login_required
def resend_confirmation():
    '''<CONFIRM><EMAIL> Send an email with a confirmation link'''
    token = current_user.generate_confirmation_token()
    text = render_template('email/confirm.txt', user=current_user, token=token)
    html = render_template('email/confirm.html', user=current_user, token=token)
    print(html)
    try:
        send_email(to=current_user.email, subject='Confirm Your Account', text=text, html=html, )
    except:
        pass
    flash('A new confirmation email has been sent to you by email.', category="info")
    return redirect(url_for('index'))
