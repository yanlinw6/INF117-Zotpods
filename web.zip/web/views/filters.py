# coding: utf-8
from .. import app
from datetime import datetime, timezone
import dateutil


@app.template_filter('default_if_none')
def _default_if_none(s, default: str = None):
    if default is None:
        default = '---'
    if s is None or s == '':
        return default
    else:
        return s


@app.template_filter('format_time')
def _format_time(dt, fmt=None):
    if fmt is None:
        fmt = '%Y-%m-%d %H:%M:%S'
    if isinstance(dt, datetime):
        return dt.strftime(fmt)
    elif isinstance(dt, str):
        date = dateutil.parser.parse(dt)
        native = date.replace(tzinfo=None)
        return native.strftime(fmt)
    else:
        print('format_time error', dt, fmt)
        return ''


@app.template_filter('to_timestamp')
def to_timestamp(dt):
    if not isinstance(dt, datetime):
        return
    if dt.tzinfo is None:
        return int(dt.replace(tzinfo=timezone.utc).timestamp() * 1000)
    else:
        return int(dt.timestamp()*1000)


@app.template_filter('de_package')
def de_package(comment):
    return sorted(list(comment.comments), key=lambda x: x.created_at, reverse=True)


@app.template_filter('find_correct_option_label')
def find_correct_option_label(options):
    base = ord('A')
    for index, op in enumerate(options):
        if op.is_correct:
            return chr(base + index)


@app.template_filter('find_user_option_label')
def find_correct_option_label(options, option_id):
    base = ord('A')
    for index, op in enumerate(options):
        if str(op.id) == str(option_id):
            return chr(base + index)