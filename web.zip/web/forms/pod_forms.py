# coding: utf-8
from flask_wtf import FlaskForm
from wtforms import (DateField, StringField, TextAreaField, SelectMultipleField, SubmitField, PasswordField,
                     BooleanField, DateTimeField, IntegerField, FloatField, SelectField, )
from flask import g
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError, NumberRange, Regexp
from flask_login import current_user
from ..models import user_models as models
from flask_ckeditor import CKEditorField


class PodCreateForm(FlaskForm):
    name = StringField(
        label='Pod Name',
        validators=[
            DataRequired(),
            Length(min=3, message='Too short. Please type in more than 3 chars'),
            Length(max=32, message='Too long. Please type less than 32 chars')
            ])
    lat = FloatField(label='Latitude', validators=[
        DataRequired(),
        NumberRange(min=32, max=35, message='Please choose a point in the campus'),
        ])

    lon = FloatField(label='Longitude', validators=[
        DataRequired(),
        NumberRange(min=-117.9, max=-117.5, message='Please choose a point in the campus'),
        ])

    submit = SubmitField(label='Submit')

