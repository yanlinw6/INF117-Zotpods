# coding: utf-8
from datetime import datetime, timedelta, timezone
from werkzeug.datastructures import FileStorage
import uuid
from pathlib import Path
import os
from flask import request


def get_utc_now():
    return datetime.now(tz=timezone.utc)


def save_file(file_obj: FileStorage, dir_path):
    """

    :param file_obj:
    :param dir_path:
    :return:
    """
    dir_path = Path(dir_path)
    if not dir_path.exists():
        os.makedirs(dir_path, exist_ok=True)
    _, ext = os.path.splitext(file_obj.filename)
    fp = dir_path / f'{str(uuid.uuid4())}{ext}'
    file_obj.save(str(fp.resolve()))
    return fp


def construct_relative_path_to_media_dir(fp: Path, media_dir: Path):
    return str(fp.relative_to(media_dir)).replace('\\', '/').replace('//', '/')


def paginate_helper():
    page = request.args.get('page', '1')
    try:
        page = int(page)
    except ValueError:
        page = 1
    per_page = request.args.get('per_page', '15')
    try:
        per_page = int(per_page)
    except ValueError:
        per_page = 15
    return page, per_page
