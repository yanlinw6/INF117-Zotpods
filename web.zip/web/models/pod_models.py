# coding: utf-8
from . import db, ModelBase
from .user_models import User
from ..utils.common import get_utc_now
from flask import url_for


class Pod(ModelBase):
    """
    Pod
    """
    __tablename__ = 'pod'

    name = db.Column(db.String(128), nullable=False)
    lat = db.Column(db.Float, nullable=False)
    lon = db.Column(db.Float, nullable=False)


class PodAppointment(ModelBase):
    """
    user appointment
    """
    __tablename__ = 'podAppointments'

    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='cascade'))
    user = db.relationship(User, backref=db.backref('pod_appointments', cascade='all,delete-orphan'))

    pod_id = db.Column(db.Integer, db.ForeignKey('pod.id', ondelete='cascade'))
    pod = db.relationship(Pod, backref=db.backref('pod_appointments', cascade='all,delete-orphan'))
    is_alarm_on = db.Column(db.Boolean, nullable=False, default=True, server_default='1')

    start = db.Column(db.DateTime, nullable=False)
    end = db.Column(db.DateTime, nullable=False)


class Feedback(ModelBase):
    """
    User feedback
    """
    __tablename__ = 'feedback'

    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='cascade'))
    user = db.relationship(User, backref=db.backref('feedbacks', cascade='all,delete-orphan'))

    pod_id = db.Column(db.Integer, db.ForeignKey('pod.id', ondelete='cascade'))
    pod = db.relationship(Pod, backref=db.backref('feedbacks', cascade='all,delete-orphan'))

    appointment_id = db.Column(db.Integer, db.ForeignKey('podAppointments.id', ondelete='cascade'))
    appointment = db.relationship(PodAppointment, backref=db.backref('feedbacks', cascade='all,delete-orphan'))

    content = db.Column(db.Text)


    