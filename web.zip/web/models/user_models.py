# coding: utf-8
# coding: utf-8
from flask import url_for, current_app
from . import db, flask_bcrypt, login, ModelBase
from datetime import datetime, timedelta
from ..utils.common import get_utc_now
from ..utils.serializer import jwt_decode, jwt_encode, JWTData


class User(ModelBase):
    __tablename__ = 'user'

    username = db.Column(db.String(64), unique=True, index=True, nullable=False)
    password_hash = db.Column(db.String(255))
    email = db.Column(db.String(64), unique=True, index=True, nullable=False)
    role = db.Column(db.Integer, default=1)  # 1 student 2 teacher
    fullname = db.Column(db.String(64))
    telephone = db.Column(db.String(64))
    identification = db.Column(db.String(18), nullable=True)
    birthday = db.Column(db.Date)
    about_me = db.Column(db.Text)
    avatar = db.Column(db.String(128), default='/static/avatars/boy.png')
    address = db.Column(db.String(255))

    is_active = db.Column(db.Boolean, default=True)
    is_superuser = db.Column(db.Boolean, default=False)
    is_confirmed = db.Column(db.Boolean, default=False)

    register_date = db.Column(db.DateTime,
                              default=lambda: get_utc_now().replace(tzinfo=None))
    last_seen = db.Column(db.DateTime(),
                          default=lambda: get_utc_now().replace(tzinfo=None),
                          onupdate=lambda: get_utc_now().replace(tzinfo=None))
    last_ip = db.Column(db.String(255))

    note = db.Column(db.Text)

    @property
    def avatar_url(self):
        if self.avatar.startswith('/static/avatars'):
            return self.avatar
        return url_for('media', file_path=self.avatar)

    def __str__(self):
        return self.username

    def __repr__(self):
        return '<User {}>'.format(self.username)

    @property
    def password(self):
        raise AttributeError('Password is not a readable attribute')

    @password.setter
    def password(self, pw):
        self.password_hash = flask_bcrypt.generate_password_hash(pw).decode('utf-8')

    def check_password(self, pw):
        return flask_bcrypt.check_password_hash(self.password_hash, password=pw)

    def verify_password(self, password):
        return self.check_password(password)

    def get_id(self):
        return self.id

    @property
    def is_authenticated(self):
        return self.is_active is True

    def refresh_time(self):
        self.last_seen = datetime.now()
        db.session.add(self)
        db.session.commit()

    @property
    def confirmed(self):
        return self.is_confirmed

    def generate_confirmation_token(self, expiration=3600):
        jwd_data = JWTData.build(data=self.id, life_time=expiration)
        key = current_app.config['SECRET_KEY']
        return jwt_encode(payload=jwd_data, key=key)

    def confirm(self, token):
        key = current_app.config['SECRET_KEY']
        ret = jwt_decode(encrypted=token, key=key)
        print(ret)
        if ret is None:
            return False
        if ret.d != self.id:
            return False
        print(ret.is_expired)
        if ret.is_expired:
            return False
        self.is_confirmed = True
        db.session.add(self)
        return True

    def generate_reset_token(self, expiration=3600):
        jwd_data = JWTData.build(data=self.email, life_time=expiration)
        key = current_app.config['SECRET_KEY']
        return jwt_encode(payload=jwd_data, key=key)

    @staticmethod
    def reset_password(token, new_password):
        key = current_app.config['SECRET_KEY']
        ret = jwt_decode(encrypted=token, key=key)
        if ret is None:
            return False
        if ret.is_expired:
            return False
        if not isinstance(ret.d, str):
            return False
        user_obj = User.query.filter(User.email == ret.d).first()

        if user_obj is None:
            return False
        user_obj.password = new_password
        db.session.add(user_obj)
        return True

    @property
    def is_student(self):
        return self.role == 1

    @property
    def is_teacher(self):
        return self.role == 2


@login.user_loader
def load_user(id):
    return User.query.get(int(id))

