"""empty message

Revision ID: f9ea4b64a3b5
Revises: 
Create Date: 2022-11-26 17:27:04.615840

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f9ea4b64a3b5'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
